package com.realismoverhaul.common;

public class CommonProxy {
    public void init() {
        // TODO: Register tile entities, server-side logic
    }
}