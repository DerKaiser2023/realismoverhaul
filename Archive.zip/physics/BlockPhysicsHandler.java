package com.realismoverhaul.physics;

public class BlockPhysicsHandler {
    public static void handleBlockGravity() {
        // TODO: Implement block gravity and support checks
    }
}