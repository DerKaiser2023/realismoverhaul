package com.realismoverhaul.physics;

public class ItemPhysicsHandler {
    public static void applyItemPhysics() {
        // TODO: Implement item drop physics, weight effects
    }
}