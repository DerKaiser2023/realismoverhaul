package com.realismoverhaul.physics;

public class ExplosionPhysicsHandler {
    public static void simulateExplosion() {
        // TODO: Implement directional shockwaves and destructible terrain
    }
}