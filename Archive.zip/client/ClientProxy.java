package com.realismoverhaul.client;

public class ClientProxy {
    public void initRenderers() {
        // TODO: Setup renderers for blocks and items
    }
}